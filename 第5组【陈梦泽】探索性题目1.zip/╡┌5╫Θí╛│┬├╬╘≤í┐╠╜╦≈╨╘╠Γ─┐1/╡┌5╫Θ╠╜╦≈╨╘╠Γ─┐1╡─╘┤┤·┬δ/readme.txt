untitled4,untitled5,gui这三个文件夹必须放在opencv的路径下，如：
D:\Qt\opencv\untitled4
D:\Qt\opencv\untitled5
D:\Qt\opencv\gui
和sources,build,这些opencv的文件夹放一起
放在其他地方会运行失败


环境如下：
Windows10 Professional 2009
Qt Creator 13.0.2
Based on Qt 6.6.3 (MSVC 2019, x86_64)
opencv-4.5.1-vc14_vc15